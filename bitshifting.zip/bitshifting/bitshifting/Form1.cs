﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bitshifting
{

    public partial class Form1 : Form
    {
        string encrypt;
        string decrypt;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            encrypt = textBox1.Text.Select(c => ((int)c) << 2).Aggregate("",
                (current, val) => current + (char)(val * 4));
            encrypt = Convert.ToBase64String(Encoding.UTF8.GetBytes(encrypt));
            Clipboard.SetText(encrypt);//copy the encrpyt
            MessageBox.Show(encrypt);//show the encrypt
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decrypt=Encoding.UTF8.GetString(Convert.FromBase64String(textBox2.Text))
                .Select(c => ((int)c) >> 2).Aggregate("",
                (current, val) => current + (char)(val / 4));//3 is replace by any number both
            //encrypt and decrypt is changed
            Clipboard.SetText(decrypt);
            MessageBox.Show(decrypt);
        }
    }
}
